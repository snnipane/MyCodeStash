import { BrowserModule,Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { PizzaHubModule } from './pizzaHub/pizza-hub.module';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CmspageModule } from './cmspage/cmspage.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PizzaHubBestsellerComponent } from './pizzaHub/pizza-hub-bestseller/pizza-hub-bestseller.component';
import { PizzaHubListComponent } from './pizzaHub/pizza-hub-list/pizza-hub-list.component';
import { PizzaHubDetailComponent } from './pizzaHub/pizza-hub-detail/pizza-hub-detail.component';
import { PizzaHubRecentComponent } from './pizzaHub/pizza-hub-recent/pizza-hub-recent.component';
import { CategoriesComponent } from './pizzaHub/categories/categories.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BannerComponent,
    PageNotFoundComponent,
    PizzaHubBestsellerComponent,
    PizzaHubListComponent,
    PizzaHubDetailComponent,
    PizzaHubRecentComponent,
    CategoriesComponent
    
    
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    HttpClientModule ,
    PizzaHubModule,
    CmspageModule,
    AppRoutingModule,
  ],
  providers: [Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
