import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaHubListComponent } from './pizza-hub-list.component';

describe('PizzaHubListComponent', () => {
  let component: PizzaHubListComponent;
  let fixture: ComponentFixture<PizzaHubListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzaHubListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaHubListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
