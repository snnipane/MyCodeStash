import { Component, OnInit } from '@angular/core';
import { PizzaHubService } from '../services/pizza-hub.service';
import { Pizza } from '../../model/pizza';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Ingredients } from '../Common/ingredients';

@Component({
  selector: 'app-pizza-hub-list',
  templateUrl: './pizza-hub-list.component.html',
  styleUrls: ['./pizza-hub-list.component.css'],
  providers: [Ingredients]
})
export class PizzaHubListComponent implements OnInit {

  title = 'Pizza Hub';
  orderID: number;
  pizzaData: Pizza[];
  error: {};
  pizzaCategory: string;

  constructor(
    private titleService: Title,
    private pizzaService: PizzaHubService,
    private route: ActivatedRoute, private router: Router,
    private ingredients: Ingredients
  ) { }

  ngOnInit() {

    this.title = 'Pizza Hub 1';
    this.titleService.setTitle(this.title);
    this.route.queryParamMap.subscribe((queryParams) => {
      if (queryParams.has('searchTerm')) {
        this.pizzaCategory = queryParams.get('searchTerm');
        if (this.pizzaCategory === 'NonVeg') {
          this.title = 'Non Veg Pizza';
        }
        else if (this.pizzaCategory === 'Veg') {
          this.title = 'Veg Pizza';
        }

      }
      this.getPizza(this.pizzaCategory);
    });


  }


  getPizza(category) {
    this.pizzaService.getPizzas()
      .subscribe(
        (data: Pizza[]) => {
          this.pizzaData = data.filter(c => c.category == category),
          this.pizzaData.forEach(element => {
            element.price = this.ingredients.getPizzaPrice(element);
            console.log(element.price);
          },
            error => this.error = error);


        });
  }
  onSubmit() {

    this.orderID = this.getRandomArbitrary(1000, 10000)

  }

  getRandomArbitrary(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min) + min);
  }
}


