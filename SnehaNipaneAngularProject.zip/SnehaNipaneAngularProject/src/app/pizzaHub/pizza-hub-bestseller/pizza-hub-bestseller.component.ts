import { Component, OnInit } from '@angular/core';
import { PizzaHubService } from '../services/pizza-hub.service';
import { Pizza } from '../../model/pizza';


@Component({
  selector: 'app-pizza-hub-bestseller',
  templateUrl: './pizza-hub-bestseller.component.html',
  styleUrls: ['./pizza-hub-bestseller.component.css']
})
export class PizzaHubBestsellerComponent implements OnInit {

  pizzaData: Pizza[];
  orderID: number;
  error: {};

  constructor(private pizzaService: PizzaHubService) { }

  ngOnInit() {
    this.pizzaService.getPizzas().subscribe(
      (data: Pizza[]) => this.pizzaData = data.filter(p => p.is_featured === true),
      error => this.error = error
    );

    console.log(this.pizzaData);
  }
  onSubmit() {

    this.orderID = this.getRandomArbitrary(1000, 10000)

  }

  getRandomArbitrary(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min) + min);
  }

}
