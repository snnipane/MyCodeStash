//Maintain different Intefaces from Future extensibilty perspective
export interface ICrust {
    id: string;
    name:string;
    price:number;
}
export interface ISize {
    id: string;
    name:string;
    price:number;
}
export interface IToppings {
    id: string;
    name:string;
    isChecked:boolean;
    price:number;
}
export interface ISauce {
    id: string;
    name:string;
    price:number;
}