import {ICrust,IToppings,ISize,ISauce} from'./IIngredents';
import { Pizza } from 'src/app/model/pizza';
import { Injectable } from '@angular/core';

@Injectable()
export class Ingredients {

    constructor(){}

    crustDetails: ICrust[] = [
        { id: "1", name: 'Wheat Thin Crust',price:50.00 },
        { id: "2", name: 'Fresh Pan Pizza',price:100.00 },
        { id: "3", name: 'Cheese Burst',price:150.00 },
        
      ];
      sizeDetails: ISize[] = [
        { id: "1", name: 'Regular',price:150.00 },
        { id: "2", name: 'Medium',price:175.00 },
        { id: "3", name: 'Large',price:200.00 },
        
      ];
      
      toppings: IToppings[] = [
        { id: "0",isChecked:false, name: 'Mushrooms',price:60.00 },
        { id: "1",isChecked:false, name: 'Fresh Tomatoes',price:60.00 },
        { id: "2",isChecked:false, name: 'Black Olives',price:60.00 },
        
      ];
      
      sauces: ISauce[] = [
        { id: "1", name: 'Marinara',price:60.00 },
        { id: "2", name: 'Cheese',price:60.00 },
        { id: "3", name: 'Ranch',price:60.00 },
        { id: "4", name: 'Mustard',price:60.00 },
        
      ];

      getPizzaPrice(pizzaData:Pizza):number
      {
        
          let totalPrice;
          let basePrice=100;
      
          var extra_cheese_price=pizzaData.extra_cheese?30:0;
          var tomato_toppings=pizzaData.tomato_toppings?60:0;
          var mushroom_toppings=pizzaData.mushroom_toppings?60:0;
          var sauce_price=this.sauces.find(k=>k.id==pizzaData.sauce).price;
          var crust_price=this.crustDetails.find(c=>c.id==pizzaData.crust).price;
          var size_price=this.sizeDetails.find(s=>s.id==pizzaData.size).price;
      
          return totalPrice=basePrice+extra_cheese_price+tomato_toppings+mushroom_toppings
          +sauce_price+crust_price+size_price;
          
      
        
      }
    
}
