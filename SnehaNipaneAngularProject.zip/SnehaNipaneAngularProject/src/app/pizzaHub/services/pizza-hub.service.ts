import { Injectable } from '@angular/core';
import { Pizza } from '../../model/pizza';
import { IPizza } from '../../model/IPizza';
import { HttpClient, HttpErrorResponse, HttpHeaders  } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class PizzaHubService {
  errorData: {};
  baseUrl = 'http://localhost:3000/pizzas';
    
  constructor(private httpClient: HttpClient) {
    }

    getPizzas() {
        return this.httpClient.get<IPizza[]>(this.baseUrl)
            .pipe(catchError(this.handleError));
    }

    

    getPizza(id: number){
       return this.httpClient.get<Pizza>(`${this.baseUrl}/${id}`)
            .pipe(catchError(this.handleError));
    }

    addPizza(pizza:Pizza): Observable<Pizza> {
        return this.httpClient.post<Pizza>(this.baseUrl, pizza, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
        .pipe(catchError(this.handleError));
    }

    updatePizza(pizza, id: number) {
        console.log(id +"in service");
        console.log(pizza +"in service");
        return this.httpClient.put<void>(`${this.baseUrl}/${pizza.id}`, pizza, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        }).pipe(catchError(this.handleError));
    
    }
    deletePizza(id: number) {
        return this.httpClient.delete(this.baseUrl + id).pipe(
          catchError(this.handleError)
        );
      }

      private handleError(errorResponse: HttpErrorResponse) {
        if (errorResponse.error instanceof ErrorEvent) {
            console.error('Client Side Error :', errorResponse.error.message);
        } else {
            console.error('Server Side Error :', errorResponse);
        }
        return throwError('There is a problem with the service. We are notified & working on it. Please try again later.');
    }
  }


