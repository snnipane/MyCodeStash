import { TestBed } from '@angular/core/testing';

import { PizzaHubService } from './pizza-hub.service';

describe('PizzaHubService', () => {
  let service: PizzaHubService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PizzaHubService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
