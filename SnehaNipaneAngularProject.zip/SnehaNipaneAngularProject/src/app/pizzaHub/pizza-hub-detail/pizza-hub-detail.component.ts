import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap} from '@angular/router';
import { PizzaHubService } from '../services/pizza-hub.service';
import { Pizza } from '../../model/pizza';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-pizza-hub-detail',
  templateUrl: './pizza-hub-detail.component.html',
  styleUrls: ['./pizza-hub-detail.component.css']
})
export class PizzaHubDetailComponent implements OnInit {

  pizza$: Observable<Pizza>;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private pizzaHubService: PizzaHubService,
    private titleService: Title) { }

    ngOnInit() {

      this.pizza$ = this.route.paramMap.pipe(
        switchMap((params: ParamMap) =>
          this.pizzaHubService.getPizza(+params.get('id'))
        )
      );

      this.titleService.setTitle('Blog Detail');
      
      
      
     
    }

}
