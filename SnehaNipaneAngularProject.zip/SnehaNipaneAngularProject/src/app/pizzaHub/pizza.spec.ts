import { Pizza } from '../model/pizza';

describe('Pizza', () => {
  it('should create an instance', () => {
    expect(new Pizza()).toBeTruthy();
  });
});
