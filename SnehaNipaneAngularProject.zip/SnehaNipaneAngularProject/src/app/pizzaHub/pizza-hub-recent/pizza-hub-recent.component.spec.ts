import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaHubRecentComponent } from './pizza-hub-recent.component';

describe('PizzaHubRecentComponent', () => {
  let component: PizzaHubRecentComponent;
  let fixture: ComponentFixture<PizzaHubRecentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzaHubRecentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaHubRecentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
