import { Component, OnInit, SimpleChanges } from '@angular/core';
import { PizzaHubService } from '../../pizzaHub/services/pizza-hub.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { Pizza } from 'src/app/model/pizza';
import { ICrust, ISauce, ISize } from '../Common/IIngredents';
import { Ingredients } from '../Common/ingredients';

@Component({
  selector: 'app-pizza-form',
  templateUrl: './pizza-form.component.html',
  styleUrls: ['./pizza-form.component.css'],
  providers: [Ingredients]
})
export class PizzaFormComponent implements OnInit {

  pageTitle: string;
  error: string;
  orderID: number;
  pizzaForm: FormGroup;
  pizzaData: Pizza;

  crustDetails: ICrust[];
  sauces: ISauce[];
  sizeDetails: ISize[];
  // This object will hold the messages to be displayed to the user
  // Notice, each key in this object has the same name as the
  // corresponding form control
  formErrors = {
    'title': '',
    'short_desc': '',
    'size': '',
    'crust': ''

  };

  // This object contains all the validation messages for this form
  validationMessages = {
    'title': {
      'required': ' Name is required.',
      'minlength': ' Name must be greater than 2 characters.',
      'maxlength': ' Name must be less than 10 characters.'
    },
    'short_desc': {
      'minlength': 'Description must be greater than 2 characters.',
      'maxlength': 'Description must be less than 10 characters.'
    },



  };


  constructor(private fb: FormBuilder,
    private pizzaService: PizzaHubService,
    private router: Router,
    private route: ActivatedRoute,
    private ingredients: Ingredients
  ) {
    this.sauces = this.ingredients.sauces;
    this.sizeDetails = this.ingredients.sizeDetails;
    this.crustDetails = this.ingredients.crustDetails;

  }

  ngOnInit(): void {

    this.pizzaData = {
      id: null,
      title: '',
      short_desc: '',
      price: 0,
      image: '',
      category: 'Veg',
      size: '1',
      crust: '1',
      extra_cheese: false,
      tomato_toppings: false,
      mushroom_toppings: false,
      sauce: '1',
      is_featured: false,
      date_time: null

    };

    const id = this.route.snapshot.paramMap.get('id');
    console.log(id);
    if (id) {
      this.pageTitle = 'Customize Your Pizza';
      console.log(id);
      this.pizzaService.getPizza(+id).subscribe(
        res => {
          this.pizzaForm.patchValue({
            id: res.id,
            title: res.title,
            short_desc: res.short_desc,
            category: res.category,
            crust: res.crust,
            price: res.price,
            image: res.image,
            size: res.size,
            extra_cheese: res.extra_cheese,
            tomato_toppings: res.tomato_toppings,
            mushroom_toppings: res.mushroom_toppings,
            sauce: res.sauce,
            is_featured: res.is_featured,
            date_time: Date,

          });
          this.pizzaData = Object.assign({}, res);
          this.pizzaData.price = this.ingredients.getPizzaPrice(this.pizzaData);
          this.pizzaForm.patchValue({
            price: res.price,
          });
        }
      );
    } else {
      this.pageTitle = 'Create Your Pizza';
      console.log(this.pageTitle);
      console.log(this.pizzaData);
      this.pizzaData.price = this.ingredients.getPizzaPrice(this.pizzaData);

    }


    this.pizzaForm = this.fb.group({
      id: [''],
      title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
      short_desc: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
      category: ['0'],
      crust: ["1"],
      price: ['0'],
      image: [''],
      size: ["1"],
      extra_cheese: [false],
      tomato_toppings: [false],
      mushroom_toppings: [false],
      sauce: ["1"],
      is_featured: ['0'],
      date_time: [''],
    });


  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes['pizzaForm'] != "undefined") {
      var change = changes['pizzaForm']
      console.log('Sneha Price');
    }
    if (!change.isFirstChange()) {
      console.log('Sneha Price');
    }
  }


  onSubmit() {


    this.mapFormValuesToPizzaModel();

    console.log(this.pizzaData + "Formdata");
    const id = this.pizzaForm.get('id').value;
    console.log(id + "Submit");
    if (id) {
      console.log(id + "start");
      this.pizzaService.updatePizza(this.pizzaData, id).subscribe(
        (err: any) => console.log(err)

      );
      console.log("end");
    }
    else {
      this.pizzaService.addPizza(this.pizzaData).subscribe(
        (err: any) => console.log(err)
      );
    }
    this.orderID = this.getRandomArbitrary(1, 1000);
  }

  mapFormValuesToPizzaModel() {
    this.pizzaData.title = this.pizzaForm.get('title').value;
    this.pizzaData.short_desc = this.pizzaForm.get('short_desc').value;
    this.pizzaData.price = this.pizzaForm.get('price').value;
    this.pizzaData.image = this.pizzaForm.get('image').value;
    this.pizzaData.id = this.pizzaForm.get('id').value;
    this.pizzaData.category = this.pizzaForm.get('category').value;
    this.pizzaData.crust = this.pizzaForm.get('crust').value;
    this.pizzaData.size = this.pizzaForm.get('size').value;
    this.pizzaData.date_time = this.pizzaForm.get('date_time').value;
    this.pizzaData.mushroom_toppings = this.pizzaForm.get('mushroom_toppings').value;
    this.pizzaData.tomato_toppings = this.pizzaForm.get('tomato_toppings').value;
    this.pizzaData.extra_cheese = this.pizzaForm.get('extra_cheese').value;
    this.pizzaData.sauce = this.pizzaForm.get('sauce').value;
    this.pizzaData.is_featured = this.pizzaForm.get('is_featured').value;


  }

  getRandomArbitrary(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min) + min);
  }

  logValidationErrors(group: FormGroup = this.pizzaForm): void {
    console.log("Hi")
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);

      this.formErrors[key] = '';
      // abstractControl.value !== '' (This condition ensures if there is a value in the
      // form control and it is not valid, then display the validation error)
      if (abstractControl && !abstractControl.valid &&
        (abstractControl.touched || abstractControl.dirty || abstractControl.value !== '')) {
        const messages = this.validationMessages[key];

        for (const errorKey in abstractControl.errors) {
          if (errorKey) {
            this.formErrors[key] += messages[errorKey] + ' ';
          }
        }
      }

      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });


    this.mapFormValuesToPizzaModel();

    this.pizzaData.price = this.ingredients.getPizzaPrice(this.pizzaData);
    this.pizzaForm.patchValue({
      price: this.pizzaData.price
    });


  }



}
