import { Component, OnInit,SimpleChanges } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PizzaHubService } from '../services/pizza-hub.service';
import { ActivatedRoute } from '@angular/router';
import { IPizza } from '../../model/IPizza';
import {ICrust,IToppings,ISize,ISauce} from'../Common/IIngredents';
import { Pizza } from '../../model/pizza';

@Component({
  selector: 'app-create-pizza',
  templateUrl: './create-pizza.component.html',
  styleUrls: ['./create-pizza.component.css']
})
export class CreatePizzaComponent implements OnInit {
  pizzaForm: FormGroup;
  constructor(private fb: FormBuilder,private _pizzaService: PizzaHubService,
    private route: ActivatedRoute,private router:Router) { }
  // This object will hold the messages to be displayed to the user
// Notice, each key in this object has the same name as the
// corresponding form control
formErrors = {
  'title': '',
  'description': '',
  'size':'',
  'crust':''
  
};

// This object contains all the validation messages for this form
validationMessages = {
  'title': {
    'required': ' Name is required.',
    'minlength': ' Name must be greater than 2 characters.',
    'maxlength': ' Name must be less than 10 characters.'
  },
  'description': {
    'minlength': 'Description must be greater than 2 characters.',
    'maxlength': 'Description must be less than 10 characters.'
  },
  'size': {
    'required': 'size Name is required.'
  },
  'crust': {
    'required': 'crust Name is required.'
  },
  
  
};
totalPrice:number;
pizza:Pizza;
orderID:number;
pageTitle: string;
pizzaData:Pizza;

crustDetails: ICrust[] = [
  { id: "1", name: 'Wheat Thin Crust',price:50.00 },
  { id: "2", name: 'Fresh Pan Pizza',price:100.00 },
  { id: "3", name: 'Cheese Burst',price:150.00 },
  
];
sizeDetails: ISize[] = [
  { id: "1", name: 'Regular',price:150.00 },
  { id: "2", name: 'Medium',price:175.00 },
  { id: "3", name: 'Large',price:200.00 },
  
];

toppings: IToppings[] = [
  { id: "0",isChecked:false, name: 'Mushrooms',price:60.00 },
  { id: "1",isChecked:false, name: 'Fresh Tomatoes',price:60.00 },
  { id: "2",isChecked:false, name: 'Black Olives',price:60.00 },
  
];

sauces: ISauce[] = [
  { id: "1", name: 'Marinara',price:60.00 },
  { id: "2", name: 'Cheese',price:60.00 },
  { id: "3", name: 'Ranch',price:60.00 },
  { id: "4", name: 'Mustard',price:60.00 },
  
];
   // Initialise the FormGroup with the 2 FormControls we need.
  // ngOnInit ensures the FormGroup and it's form controls are
  // created when the component is initialised
  ngOnInit(): void {

    

    /*this.pizza =  {
      id: null,
      title: '',
      short_desc: '',
      price: 0,
      image: '',
      category: '',
      size:'',
      crust:'',
      extra_cheese:false,
      toppings:[],
      sauce:'',
      is_featured:false,
      date_time:null

    };*/


    this.pizzaForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
      description: ['', [, Validators.minLength(2), Validators.maxLength(50)]],
      extra_cheese: [false, [, Validators.minLength(2), Validators.maxLength(50)]],
      crust: ["1", [Validators.required]],
      size:["1", [Validators.required]],
      sauce:["1"],
      toppings:[[false,false,false]],
      price:[0],
      
    });
    this.pizza.price=this.pizza.price +this.sizeDetails.find(c=>c.id==this.pizzaForm.get('size').value).price
    +this.sauces.find(c=>c.id==this.pizzaForm.get('crust').value).price
    +this.sauces.find(c=>c.id==this.pizzaForm.get('sauce').value).price;
  
    this.route.paramMap.subscribe(parameterMap => {
      const pizzaId = +parameterMap.get('id');
      if (pizzaId) {
        this.pageTitle = 'Customize Your Pizza';
        this.getPizza(pizzaId);
      }
      else {
        this.pageTitle = 'Create Your Pizza';
        
      }
    });
   
  }

  ngOnChanges(changes: SimpleChanges) {
    var index;
    console.log("Hi From On changes")
    this.pizzaForm.get('crust').valueChanges.subscribe(val=>
      {index={val};
        this.totalPrice=this.sizeDetails.find(index).price
        
      });
      
  }

  getPizza(id: number) {
    console.log('id:'+id);
     
    this._pizzaService.getPizza(id)
      .subscribe(
        (data: Pizza) => 
        (this.pizza=Object.assign({},data),
        this.editPizza(this.pizza),
        (err: any) => console.log(err)),
        
      )
      console.log("Hi");
      this.pizzaData=Object.assign({},this.pizza);
      console.log(this.pizza);
     
      

     
  }

  editPizza(pizza: IPizza) {
    this.pizzaForm.patchValue({
      id:pizza.id,
      title: pizza.title,
      short_desc: pizza.short_desc,
      category: pizza.category,
      crust: pizza.crust,
      price:pizza.price,
      image:pizza.image,
      size:pizza.size,
      extra_cheese:pizza.extra_cheese,
      //toppings:pizza.toppings,
      sauce:pizza.sauce,
      is_featured:pizza.is_featured,
      date_time:Date
      //revisit for form array and other fields

    });
    /*for(let index of this.pizza.toppings.values())
      {
        console.log((index));
        this.toppings[parseInt(index)-1].isChecked=true;
      }*/
  }

 
  onSubmit(): void {
    
    this.logValidationErrors(this.pizzaForm);
    this.mapFormValuesToPizzaModel();
  
    console.log("Hi On Submit")
    console.log(this.pizza.id)
    if (this.pizza.id) {
     
      this._pizzaService.updatePizza(this.pizza,this.pizza.id).subscribe(
       (err: any) => console.log(err)
      );
      console.log("Hi On Submit3")
    } else {
      const newPizza: Pizza = Object.assign({}, this.pizza);
      this._pizzaService.addPizza(newPizza).subscribe(
      (err: any) => console.log(err)
      );
      this.pizzaForm.reset();
    }
    this.orderID=this.getRandomArbitrary(1, 1000);

  }

  mapFormValuesToPizzaModel() {
    console.log("pizzaka detail:"+this.pizzaForm)
    this.pizza.title = this.pizzaForm.value.title;
    this.pizza.short_desc = this.pizzaForm.value.short_desc;
    this.pizza.price = this.pizzaForm.value.price;
    this.pizza.image = this.pizzaForm.value.image;
    this.pizza.id = this.pizzaForm.value.id;
    this.pizza.category = this.pizzaForm.value.category;
    this.pizza.crust = this.pizzaForm.value.crust;
    this.pizza.size = this.pizzaForm.value.size;
    this.pizza.date_time = this.pizzaForm.value.date_time;
    //this.pizza.toppings = this.pizzaForm.value.toppings;
    this.pizza.extra_cheese = this.pizzaForm.value.extra_cheese;
    this.pizza.sauce = this.pizzaForm.value.sauce;
    this.pizza.is_featured = this.pizzaForm.value.is_featured;
    
    
  }

  getRandomArbitrary(min:number, max:number):number {
    return Math.floor(Math.random() * (max - min) + min);
  }

  logValidationErrors(group: FormGroup = this.pizzaForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
  
      this.formErrors[key] = '';
      // abstractControl.value !== '' (This condition ensures if there is a value in the
      // form control and it is not valid, then display the validation error)
      if (abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty || abstractControl.value !== '')) {
        const messages = this.validationMessages[key];
  
        for (const errorKey in abstractControl.errors) {
          if (errorKey) {
            this.formErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
  
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
    
  }

}
