export class Pizza {
    id: number;
    title: string;
    short_desc: string;
    price: number;
    image: string;
    category: string;
    size:string;
    crust:string;
    extra_cheese:boolean;
    toppings:string;
    sauce:string;
    is_featured:boolean;
    date_time:Date

}
