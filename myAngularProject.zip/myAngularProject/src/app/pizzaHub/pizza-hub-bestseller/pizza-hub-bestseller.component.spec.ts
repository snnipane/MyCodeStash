import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaHubBestsellerComponent } from './pizza-hub-bestseller.component';

describe('PizzaHubBestsellerComponent', () => {
  let component: PizzaHubBestsellerComponent;
  let fixture: ComponentFixture<PizzaHubBestsellerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzaHubBestsellerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaHubBestsellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
