import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ PizzaHubBestsellerComponent} from '../pizzaHub/pizza-hub-bestseller/pizza-hub-bestseller.component'

import {PizzaHubRoutingModule} from './pizza-hub-routing.module';
import { CreatePizzaComponent } from './create-pizza/create-pizza.component';
import { ModalComponent } from './modal/modal.component'


@NgModule({
  declarations: [CreatePizzaComponent, ModalComponent],
  imports: [
    CommonModule,
    PizzaHubRoutingModule
  ],
  exports: [
   
  ],
})
export class PizzaHubModule { }
