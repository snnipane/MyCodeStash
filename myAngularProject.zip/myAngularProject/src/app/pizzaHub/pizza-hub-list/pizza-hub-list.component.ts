import { Component, OnInit } from '@angular/core';
import { PizzaHubService } from '../pizza-hub.service';
import { Pizza } from '../../model/pizza';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-pizza-hub-list',
  templateUrl: './pizza-hub-list.component.html',
  styleUrls: ['./pizza-hub-list.component.css']
})
export class PizzaHubListComponent implements OnInit {

  title = 'Pizza Hub';
  pizzaData: Pizza[];
  error: {};
  pizzaCategory:string;

  constructor(
    private titleService: Title,
    private pizzaService: PizzaHubService,
    private route: ActivatedRoute,private router:Router
    ) { }

  ngOnInit() {

    this.title = 'Pizza Hub 1';
    this.titleService.setTitle(this.title);
    this.route.queryParamMap.subscribe((queryParams) => {
      if (queryParams.has('searchTerm')) {
        this.pizzaCategory = queryParams.get('searchTerm');
        if(this.pizzaCategory==='NonVeg')
        {
          this.title='Non Veg Pizza';
        }
        else {
          this.title='Veg Pizza';
      } 

      }
      this.getPizza(this.pizzaCategory);
    });
    

  }
  

  getPizza(category)
    {
      this.pizzaService.getPizzas().subscribe(
        (data: Pizza[]) => this.pizzaData = data.filter(c=>c.category==category),
        error => this.error = error);
    }
  }


