import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaHubDetailComponent } from './pizza-hub-detail.component';

describe('PizzaHubDetailComponent', () => {
  let component: PizzaHubDetailComponent;
  let fixture: ComponentFixture<PizzaHubDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzaHubDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaHubDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
