import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-hub-recent',
  templateUrl: './pizza-hub-recent.component.html',
  styleUrls: ['./pizza-hub-recent.component.css']
})
export class PizzaHubRecentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
