import { Component, OnInit,SimpleChanges } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PizzaHubService } from '../pizza-hub.service';
import { ActivatedRoute } from '@angular/router';
import { IPizza } from '../../model/IPizza';
import {ICrust,IToppings,ISize,ISauce} from'../../model/IIngredents';
import { Pizza } from '../../model/pizza';

@Component({
  selector: 'app-create-pizza',
  templateUrl: './create-pizza.component.html',
  styleUrls: ['./create-pizza.component.css']
})
export class CreatePizzaComponent implements OnInit {
  pizzaForm: FormGroup;
  constructor(private fb: FormBuilder,private _pizzaService: PizzaHubService,
    private route: ActivatedRoute,private router:Router) { }
  // This object will hold the messages to be displayed to the user
// Notice, each key in this object has the same name as the
// corresponding form control
formErrors = {
  'title': '',
  'description': '',
  'size':'',
  'crust':''
  
};

// This object contains all the validation messages for this form
validationMessages = {
  'title': {
    'required': ' Name is required.',
    'minlength': ' Name must be greater than 2 characters.',
    'maxlength': ' Name must be less than 10 characters.'
  },
  'description': {
    'minlength': 'Description must be greater than 2 characters.',
    'maxlength': 'Description must be less than 10 characters.'
  },
  'size': {
    'required': 'size Name is required.'
  },
  'crust': {
    'required': 'crust Name is required.'
  },
  
  
};

pizza:IPizza;
orderID:number;
pageTitle: string;
crustDetails: ICrust[] = [
  { id: "1", name: 'Wheat Thin Crust',price:50.00 },
  { id: "2", name: 'Fresh Pan Pizza',price:100.00 },
  { id: "3", name: 'Cheese Burst',price:150.00 },
  
];
sizeDetails: ISize[] = [
  { id: "1", name: 'Regular',price:150.00 },
  { id: "2", name: 'Medium',price:175.00 },
  { id: "3", name: 'Large',price:200.00 },
  
];

toppings: IToppings[] = [
  { id: "1", name: 'Mushrooms',price:60.00 },
  { id: "2", name: 'Fresh Tomatoes',price:60.00 },
  { id: "3", name: 'Black Olives',price:60.00 },
  
];

sauces: ISauce[] = [
  { id: "1", name: 'Marinara',price:60.00 },
  { id: "2", name: 'Cheese',price:60.00 },
  { id: "3", name: 'Ranch',price:60.00 },
  { id: "4", name: 'Mustard',price:60.00 },
  
];
   // Initialise the FormGroup with the 2 FormControls we need.
  // ngOnInit ensures the FormGroup and it's form controls are
  // created when the component is initialised
  ngOnInit(): void {
    this.pizzaForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
      description: ['', [, Validators.minLength(2), Validators.maxLength(50)]],
      extra_cheese: [false, [, Validators.minLength(2), Validators.maxLength(50)]],
      image:[],
      toppings:[],
      crust: [1, [Validators.required]],
      size:[1, [Validators.required]],
      sauce:[1, []],
      price:[0]
    });

    this.route.paramMap.subscribe(params => {
      const pizzaId = +params.get('id');
      if (pizzaId) {
        this.pageTitle = 'Customize Pizza';
        this.getPizza(pizzaId);
      }
      else {
        this.pageTitle = 'Create Your Pizza';
        this.pizza =  {
          id: null,
          title: '',
          short_desc: '',
          price: 0,
          image: '',
          category: '',
          size:'',
          crust:'',
          extra_cheese:false,
          toppings:'',
          sauce:'',
          is_featured:false,
          date_time:null

        };
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    
    var price=this.crustDetails.find(c=>c.id==this.pizzaForm.get('crust').value).price;
    price=price+this.sizeDetails.find(c=>c.id==this.pizzaForm.get('size').value).price;
    price=price+this.sauces.find(c=>c.id==this.pizzaForm.get('sauce').value).price;
    price=price+this.sauces.find(c=>c.id==this.pizzaForm.get('sauce').value).price;
    
    this.pizzaForm.setValue({
      price:price
    });
  }

  getPizza(id: number) {
    this._pizzaService.getPizza(id)
      .subscribe(
        (pizza: IPizza) => this.editPizza(pizza),
        (err: any) => console.log(err)
      );
  }

  editPizza(pizza: IPizza) {
    this.pizzaForm.patchValue({
      title: pizza.title,
      category: pizza.category,
      crust: pizza.crust,
      price:pizza.price,
      image:pizza.image,
      size:pizza.size,
      extra_cheese:pizza.extra_cheese,
      toppings:pizza.toppings
      
      //revisit for form array and other fields-kudvenkat ang 6 edit

    });
  }

 
  onSubmit(): void {
    this.logValidationErrors(this.pizzaForm);
    this.mapFormValuesToPizzaModel();
  
    if (this.pizza.id) {
      this._pizzaService.updatePizza(this.pizza).subscribe(
        () => this.router.navigate(['/']),
        (err: any) => console.log(err)
      );
    } else {
      this._pizzaService.addPizza(this.pizza).subscribe(
      
        (err: any) => console.log(err)
      );
    }
    this.orderID=this.getRandomArbitrary(1, 1000);

  }

  mapFormValuesToPizzaModel() {
    this.pizza.title = this.pizzaForm.value.title;
    this.pizza.id = this.pizzaForm.value.id;
    this.pizza.category = this.pizzaForm.value.category;
    this.pizza.crust = this.pizzaForm.value.crust;
    this.pizza.date_time = this.pizzaForm.value.date_time;
  }

  getRandomArbitrary(min:number, max:number):number {
    return Math.floor(Math.random() * (max - min) + min);
  }

  logValidationErrors(group: FormGroup = this.pizzaForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
  
      this.formErrors[key] = '';
      // abstractControl.value !== '' (This condition ensures if there is a value in the
      // form control and it is not valid, then display the validation error)
      if (abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty || abstractControl.value !== '')) {
        const messages = this.validationMessages[key];
  
        for (const errorKey in abstractControl.errors) {
          if (errorKey) {
            this.formErrors[key] += messages[errorKey] + ' ';
          }
        }
      }
  
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
    
  }

}
