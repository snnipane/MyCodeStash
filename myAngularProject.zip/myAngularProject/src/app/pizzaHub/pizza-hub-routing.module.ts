import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {PizzaHubListComponent} from '../pizzaHub/pizza-hub-list/pizza-hub-list.component'
import {PizzaHubDetailComponent} from '../pizzaHub/pizza-hub-detail/pizza-hub-detail.component'
import {CreatePizzaComponent} from '../pizzaHub/create-pizza/create-pizza.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {path: 'pizza', component: PizzaHubListComponent},
  {path: 'pizza/Veg', component: PizzaHubListComponent},
  {path: 'pizza/NonVeg', component: PizzaHubListComponent},
  {path: 'pizza/:id', component: PizzaHubDetailComponent},
  { path: 'create', component: CreatePizzaComponent },
  { path: 'edit/:id', component: CreatePizzaComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule,FormsModule,ReactiveFormsModule]
})
export class PizzaHubRoutingModule { }
